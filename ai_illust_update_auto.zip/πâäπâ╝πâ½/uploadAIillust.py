from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from datetime import datetime
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support import expected_conditions as EC
import openpyxl
import time
import socket

computer_name = socket.gethostname()

# ChromeDriverのパスを指定
driver_path = 'C:\chromedriver.exe'
service = Service(driver_path)

# 投稿画像格納先
NETWORK_PATH = r"\\" + computer_name + r"\uploadFolder"

# 今日の日付を取得
today = datetime.today()

# 投稿情報の台帳を読み込む
excel_file_path =  r"\\" + computer_name + r"\layoutdata\投稿データ一覧.xlsx"
workbook = openpyxl.load_workbook(excel_file_path, data_only=True)

sheet_name = 'AC_ログイン情報'
sheet = workbook[sheet_name]

#イラスト屋のログイン情報
USER_ID = sheet['D3'].value
PASSWORD = sheet['D4'].value

sheet_name = '一覧'
sheet = workbook[sheet_name]
# 取得した値を格納するリスト
upload_data = []
for row in range(4, sheet.max_row + 1):
    sheet_date = sheet[f'B{row}'].value
    sheet_status = sheet[f'C{row}'].value
    value_item = []

    # 台帳の参照先をすべて参照終わったら読込やめる
    if sheet_date == None:
        break

    if sheet_date.month == today.month and sheet_date.day == today.day:
        if sheet_status == None:
            value_item.append(sheet[f'D{row}'].value) # データ形式
            value_item.append(sheet[f'E{row}'].value) # ファイル名
            value_item.append(sheet[f'F{row}'].value) # タイトル名
            value_item.append(sheet[f'G{row}'].value) # プリセット
            value_item.append(sheet[f'H{row}'].value) # タグ
            value_item_cat = []
            value_item_cat.append(sheet[f'I{row}'].value) # カテゴリー1
            value_item_cat.append(sheet[f'J{row}'].value) # カテゴリー2
            value_item_cat.append(sheet[f'K{row}'].value) # カテゴリー3
            value_item.append(value_item_cat) # カテゴリー
            value_item.append(sheet[f'L{row}'].value) # 説明
            value_item.append(sheet[f'M{row}'].value) # チュートリアル
            value_item.append(sheet[f'N{row}'].value) # AI
            value_item.append(sheet[f'O{row}'].value) # AI_URL
            value_item_open_link = []
            if sheet[f'P{row}'].value != None:
                value_item_open_link.append(sheet[f'P{row}'].value) # 公開サイト_1
            if sheet[f'Q{row}'].value != None:
                value_item_open_link.append(sheet[f'Q{row}'].value) # 公開サイト_2
            if sheet[f'R{row}'].value != None:
                value_item_open_link.append(sheet[f'R{row}'].value) # 公開サイト_3
            value_item.append(value_item_open_link) # 公開サイト
            value_item.append(sheet[f'S{row}'].value) # URL_自動登録
            value_item.append(sheet[f'T{row}'].value) # 特記事項
            upload_data.append(value_item)

# チェックボックスの項目名とチェックボックスを紐づけて選択させる。
def checked_checkbox(cat_list):
    for cat in cat_list:
        cat_element = driver.find_elements(By.XPATH, f"//label[contains(text(), '{cat}')]")
        for cat_item in cat_element:
            cat_value = cat_item.get_attribute('for').split("-")[1]
            script = f"document.querySelector('input[type=\"checkbox\"][value=\"{cat_value}\"]').checked = true;"
            driver.execute_script(script)

# 登録したタグのプリセットからタグを取得
def select_preset(select_tag):
    select = Select(driver.find_element(By.ID, 'store-tags'))
    select_text = select_tag
    select.select_by_visible_text(select_text)

# タグをエディタに追加する
def edit_tag(tag_list):
    for tag in tag_list.split():
        script = f"$('#ntags').tagEditor('addTag', '{tag}');"
        driver.execute_script(script)

# 選択したファイル形式と一致する画像ファイルを挿入
def upload_image_file(format, path):
    if format == "JPEG":
        driver.find_element(By.ID, 'jpg_path').send_keys(path)
    if format == "AI":
        driver.find_element(By.ID, 'eps_path').send_keys(path)
    if format == "PNG":
        driver.find_element(By.ID, 'png_path').send_keys(path)

if len(upload_data) == 0:
    print("資料が更新されていません。再度確認してください。")
    input("Enterキーを押して終了します。")
    exit(0)

for data in upload_data:

    # ブラウザを起動
    driver = webdriver.Chrome(service=service)
    # 指定されたURLにアクセス
    url = 'https://www.ac-illust.com/creator/upload.php'
    driver.get(url)

    # ログインページで情報入力し、ログイン
    if USER_ID == None or PASSWORD == None:
        print("シート「AC_ログイン情報」にログイン情報を入力してください。")
        driver.quit()
        input("Enterキーを押して終了します。")
        exit(0)

    driver.find_element(By.ID, 'userid').send_keys(USER_ID)
    driver.find_element(By.ID, 'passwd').send_keys(PASSWORD)
    driver.find_element(By.XPATH, "//button[@type='submit']").click()

    # ログイン処理が完了するまで待機
    time.sleep(5)

    try:
        # 画面表示時のポップアップを閉じる
        driver.find_element(By.XPATH, '//*[@id="disasterPrevention"]/div/div/div[1]/button').click()
    except NoSuchElementException:
        print("ログイン時の表示ポップを探しましたが、見つかりませんでした。このまま処理を続行します。")

    print(data[1] + "：アップロード実行中")

    # 申請用の画像を挿入
    file_path = NETWORK_PATH + f"\\" + data[1]
    upload_image_file(data[0], file_path)

    # 申請画像のタイトルを指定
    driver.find_element(By.NAME, 'title').send_keys(data[1])

    # タグを挿入する
    if data[3] == None and data[4] == None:
        print("タグ指定がありません。タグを追加してください。")
        input("Enterキーを押して終了します。")
        exit(0)
    if data[3] != None:
        select_preset(data[3])
    elif data[4] != None:
        edit_tag(data[4])

    tag_cnt = int(driver.find_element(By.ID, 'jq-ntags-count-text').text)
    if tag_cnt == 0:
        print("追加したタグの数が" + str(tag_cnt) + "件です。再度確認してください。")

    #カテゴリのチェックボックスを選択
    checked_checkbox(data[5])

    # 説明を記載
    if data[6] != None:
        driver.find_element(By.ID, 'illust_comment').send_keys(data[6])

    # チュートリアルを記載
    if data[7] != None:
        driver.find_element(By.ID, 'illust_video_url').send_keys(data[7])

    #ai有効化
    if data[8] == "○":
        script = f"document.querySelector('input[type=\"checkbox\"][id=\"illust_ai_status\"]').click();"
        driver.execute_script(script)
        script = f"document.querySelector('input[id=\"illust_ai_url\"]').value = '{data[9]}';"
        driver.execute_script(script)

    # 公開サイトを記載
    if len(data[10]) != 0:
        i = 1
        for url in data[10]:
            if i > 1:
                # 代表公開サイトが2つ以上の場合、記載先を増やすようにする
                script = "javascript:addMoreURLInput()"
                driver.execute_script(script)
            driver.find_element(By.XPATH, f'//*[@id="input_urls"]/div[{i}]/div/input').send_keys(url)
            i += 1
        if data[11] == "○":
            script = '$("#agree_url").click()'
            driver.execute_script(script)

    # 特記事項を記載
    if data[12] != None:
        driver.find_element(By.ID, 'author_note').send_keys(data[12])

    #画像申請時のボタンクリックの処理
    upload_button = driver.find_element(By.XPATH, '//*[@id="submit_btn"]')
    driver.execute_script("arguments[0].click();", upload_button)
    upload_button_recheck = driver.find_element(By.XPATH, '//*[@id="exec-upload"]')
    driver.execute_script("arguments[0].click();", upload_button_recheck)

    print(data[0] + "：アップロード完了")
    driver.quit()

